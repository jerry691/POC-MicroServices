package com.example.finance_report;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
