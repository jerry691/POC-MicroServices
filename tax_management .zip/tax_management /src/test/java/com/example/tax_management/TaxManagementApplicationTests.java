package com.example.tax_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
